# Vel Claude handoff – context snapshot

Start: docs/claude-handoff/00-START-HERE.md

This ZIP contains the preparation package plus selected source, prototype, license and specification snapshots at their original repository-relative paths. It is not a complete, installable application checkout. No node_modules, .git, production dist or browser own-library data is included. The live Vel repository and current human approvals remain authoritative. Use the matching live repo for implementation; do not overwrite newer files with these snapshots. AGENTS.md here is a copy of the common parent instruction file.

The source-index records hashes and untracked/dirty source status. Work only on the agreed task write-set. The full inventory and addon sources are references, not required initial reading for every agent.
