(()=>Object.keys(EFFECTS).length)()
