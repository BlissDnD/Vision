# AGENTS.md — közös főfájl minden agentnek (`~/Desktop/melo/CLAUDE/`)

> **Minden agent minden session elején ezt olvassa be először.** Magyarul válaszolj, egyszerűen. Kód, azonosítók és commit üzenetek angolul.

## 1. Session indítás
1. Olvasd be ezt a fájlt.
2. Keresd meg a projektet a **4. táblázatban**, és olvasd be a projekt saját belépési fájlját. **Ha a projektnek saját rendszere van** (Vel: `CLAUDE.md` + `HANDOFF.md`; GH: `00-index.md` + `folyamat.md`), az az irányadó, és a `handoff/` szabály rá nem vonatkozik.
3. Saját rendszer nélküli projektnél olvasd be a `handoff/` mappa **legutóbbi**, az adott projekthez tartozó bejegyzését (fájlnév szerint a legfrissebb).
4. Mielőtt bármit csinálsz, foglald össze 2–3 mondatban: hol tart a projekt, mi a következő lépés.

## 2. Handoff szabály (saját rendszer nélküli projekteknek)
- **Minden mérföldkő után** kötelező új handoff bejegyzést írni a `handoff/` mappába (`~/Desktop/melo/CLAUDE/handoff/`).
- Fájlnév: `YYYY-MM-DD_HHMM_<projekt>_<rovid-cim>.md`
- Régi bejegyzést nem írunk felül: mindig új fájl.
- A bejegyzés után frissítsd a 4. táblázat „Állapot / legutóbbi handoff” oszlopát.

## 3. Handoff sablon
```markdown
# Handoff — <projekt> — <dátum>
**Agent:** <melyik agent / eszköz>
**Mérföldkő:** <mi lett kész>

## Jelenlegi állapot
-

## Utolsó döntések (és miért)
-

## Nyitott kérdések / ismert hibák
-

## Következő lépés
-

## Érintett fájlok
-
```

## 4. Aktív projektek
| Projekt | Leírás | Belépési pont | Állapot / legutóbbi handoff |
|---|---|---|---|
| **Vel** | rétegalapú WebGL2 vizuális és motion editor (a Látomás Stúdió utódja), TS + esbuild, git | `muchdesigner/vel/CLAUDE.md` | **Saját rendszer:** `muchdesigner/vel/HANDOFF.md` (aktuális állapot), `PROGRESS.md`, `FUNKCIO-LELTAR.md`. Mérföldkő előtt a felhasználó jóváhagyása kell. |
| GH honlap | Generációk Háza honlap újratervezése (WCAG 2.1 AA, React) | `GH/00-index.md` | Saját rendszer: `GH/folyamat.md` (lépések, státusz), `GH/dontesek.md` |
| SoulSigil | személyiség-alapú WebGL/WebGPU lélek-logó generátor | – (a mappája nincs ebben a könyvtárban) | – |

## 5. Lezárt / régi
| Projekt | Hol | Megjegyzés |
|---|---|---|
| Látomás Stúdió (régi) | forrás: `muchdesigner/latomas-src/` (az 5173-as porton fut); régi egyfájlos buildek: `muchdesigner/vel/legacy/` | **Nem fejlesztjük tovább**, a Vel váltotta. Ne módosítsd. Munkanaplói: `muchdesigner/vel/docs/archiv/logs/` (utolsó: `2026-10-17_1440_latomas-studio_modulok-ts.md`). |
